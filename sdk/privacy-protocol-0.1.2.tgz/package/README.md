# privacy-protocol

Privacy Protocol is a plug-and-play privacy middleware for EVM dApps.

This package exposes:

- `privacy-protocol/core`: low-level TypeScript SDK for private deposit, private execution, and private withdrawal
- `privacy-protocol/hooks`: React hooks built on top of the core SDK

The Noir circuit is bundled in the package. Users do not need to import a circuit artifact manually.

## Installation

```bash
npm install privacy-protocol ethers
```

For React integrations:

```bash
npm install react
```

No framework-specific aliasing is required. The package exports are configured for both ESM (`import`) and CommonJS (`require`) consumers, with browser-safe entrypoints for frontend builds. `@aztec/bb.js` is loaded lazily at runtime and Buffer BigInt compatibility methods are polyfilled automatically when missing.

## Integration Requirements

Before integration, ensure all of the following are available:

1. A deployed `PrivacyProtocolPool` address on the target chain
2. An RPC endpoint for that chain
3. An `ethers` provider and signer
4. Supported token addresses on that chain
5. Pool configuration that includes each token via `addSupportedToken`
6. User token balance and ERC20 approval to `poolAddress`
7. Storage for note data (`secret`, `nullifier`, `commitment`, `amount`, `txHash`)

If you are using a relayer flow, additionally ensure:

8. A deployed relayer endpoint (`POST /relay`)
9. A relayer-aware proof format where public inputs include relayer address and relayer fee words
10. A pool contract that supports relayer batch submission (`executeBatch(bytes[] proofs, bytes32[][] publicInputs)`)

## Core SDK

### Initialize

```ts
import { ethers } from "ethers";
import { PrivacyProtocolSDK } from "privacy-protocol/core";

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const poolAddress = process.env.PRIVACY_PROTOCOL_POOL_ADDRESS as string;
const sdk = new PrivacyProtocolSDK(provider, poolAddress);
```

### Initialize (Private Execution Uses Relayer)

```ts
const sdk = new PrivacyProtocolSDK(provider, poolAddress, undefined, {
  relayer: {
    url: "https://your-relayer.example.com",
    endpoint: "/relay",
    relayerPublicInputIndex: 6,
    relayerAddress: "0xRelayerAddress",
    feePublicInputIndex: 7,
    relayerFeeWei: "1000000000000000",
  },
});
```

### Deposit

```ts
const signer = await provider.getSigner();
const tokenAddress = "0xTokenAddress";
const amount = ethers.parseUnits("10", 18);

const token = new ethers.Contract(
  tokenAddress,
  ["function approve(address spender, uint256 value) returns (bool)"],
  signer,
);

await (await token.approve(poolAddress, amount)).wait();

const depositResult = await sdk.deposit(tokenAddress, amount, signer);
```

`depositResult` returns:

- `secret`
- `nullifier`
- `commitment`
- `txHash`

### Withdraw

```ts
const leaves = await sdk.getLeaves();

const withdrawResult = await sdk.withdraw(
  tokenAddress,
  recipientAddress,
  amountToWithdraw,
  secret,
  nullifier,
  amountInPool,
  leaves,
  signer,
);
```

### Execute Private Action

```ts
const leaves = await sdk.getLeaves();
const actionId = ethers.keccak256(ethers.getBytes(secret));

const executeResult = await sdk.executeAction(
  tokenAddress,
  amountToSpend,
  targetContractAddress,
  encodedCallData,
  actionId,
  secret,
  nullifier,
  amountInPool,
  leaves,
  signer,
);
```

### Fetch Private Transaction Metadata

```ts
const txDetails = await sdk.getPrivateTransactionDetails(txHash);
```

Private executions (`executeAction`, `withdraw`) return a relay submission id as `txHash` in the format `relay:<request_id>`.

## React Hooks

All hooks are exported from `privacy-protocol/hooks`.
Provide your own `ethers` `provider` and `signer`.

## Relayer Integration (Rust Service)

The Rust relayer in this repository accepts:

```json
{
  "proof": "0x...",
  "public_inputs": ["0x...", "0x..."]
}
```

The relayer enforces:

- `public_inputs[RELAYER_PUBLIC_INPUT_RELAYER_INDEX] == relayer_wallet_address`
- `public_inputs[RELAYER_PUBLIC_INPUT_FEE_INDEX] >= estimated_gas_cost * 1.1`

Important:

- The default Privacy Protocol circuit currently used for `executeAction` / `withdraw` proof generation exposes six public inputs.
- A production relayer path should use a relayer-aware circuit and matching on-chain verifier/contract interface so relayer address and fee are part of the validated statement.
- SDK relayer transport can inject relayer address and fee words into configured public-input indices before sending to `/relay`.

### usePrivacyProtocol

```ts
import { usePrivacyProtocol } from "privacy-protocol/hooks";

const { sdk, isReady } = usePrivacyProtocol({
  poolAddress,
  provider,
  signer,
  relayer: {
    url: "https://your-relayer.example.com",
    relayerPublicInputIndex: 6,
    relayerAddress: "0xRelayerAddress",
    feePublicInputIndex: 7,
    relayerFeeWei: "1000000000000000",
  },
});
```

### useDeposit

```ts
import { useDeposit } from "privacy-protocol/hooks";

const { deposit, data, note, isPending, error } = useDeposit({
  poolAddress,
  provider,
  signer,
});

await deposit({
  token: tokenAddress,
  amount,
});
```

### useWithdraw

```ts
import { useWithdraw } from "privacy-protocol/hooks";

const { withdraw, data, nextNote, isPending, error } = useWithdraw({
  poolAddress,
  provider,
  signer,
});

await withdraw({
  token: tokenAddress,
  recipient: recipientAddress,
  amount: withdrawAmount,
  note,
});
```

`note` can be replaced with explicit values:

- `secret`
- `nullifier`
- `amountInPool`

### useExecuteAction

```ts
import { useExecuteAction } from "privacy-protocol/hooks";

const { executeAction, data, nextNote, isPending, error } = useExecuteAction({
  poolAddress,
  provider,
  signer,
});

await executeAction({
  token: tokenAddress,
  amount: amountToSpend,
  target: targetContractAddress,
  data: encodedCallData,
  note,
});
```

### useCommitments

```ts
import { useCommitments } from "privacy-protocol/hooks";

const { commitments, refetch, isLoading, error } = useCommitments({
  poolAddress,
  provider,
  signer,
  fromBlock: 0,
});
```

### usePrivateTransactionDetails

```ts
import { usePrivateTransactionDetails } from "privacy-protocol/hooks";

const { data, isLoading, error, refetch } = usePrivateTransactionDetails({
  poolAddress,
  provider,
  signer,
  txHash,
});
```

### useLocalNotes

```ts
import { useLocalNotes } from "privacy-protocol/hooks";

const { notes, addNote, upsertNote, removeNote, clearNotes, getNoteByCommitment } =
  useLocalNotes();
```

## Minimal Integration Flow

1. Create SDK instance with `poolAddress` + `provider`
2. Approve token spend to `poolAddress`
3. Deposit and persist returned note data
4. Rebuild commitments with `getLeaves`
5. Execute private action or withdraw
6. Persist next note returned from execution
7. Display metadata via `getPrivateTransactionDetails` or `usePrivateTransactionDetails`

## Environment Configuration

Recommended variables:

```bash
RPC_URL=https://your-rpc-url
PRIVACY_PROTOCOL_POOL_ADDRESS=0xYourPoolAddress
```

For frontend apps:

```bash
NEXT_PUBLIC_PRIVACY_PROTOCOL_POOL_ADDRESS=0xYourPoolAddress
```

## Operational Notes

- The target contract in `executeAction` must support calls where `msg.sender` is the privacy proxy.
- `actionId` must be `keccak256(secret)` for private proxy withdrawal compatibility.
- Notes are required to continue private spending. Losing note data prevents recovery of shielded funds.
- `getLeaves` should be called against the same chain and pool where deposits occurred.

## Common Failure Cases

- `TokenNotSupported`: token has not been added to pool support list.
- `InvalidProof`: incorrect note values, stale leaves/root, or mismatched action context.
- `NullifierUsed`: note already spent.
- `InsufficientBalance`: attempting to spend more than note amount or pool token balance.

## Compatibility

- Ethers v6
- React 18 or React 19 for hooks
- EVM chains where the Privacy Protocol contracts are deployed
